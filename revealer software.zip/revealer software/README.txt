This software gets the passwords and names of all wifi networks 
used by a computer.

This software is for educational purposes only!!

1. put folder int flash drive.
2. plug flash drive into any computer.
3. run the program(can be run directly from flashdrive).
4. Follow the prompts.
5. if you choose to save the passwords a file named "passwords.txt" 
   will be created and or added on to.

Created By: Drew Quashie