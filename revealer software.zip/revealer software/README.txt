Can be used on Chrome OS and Windows(Not sure about Mac)

This software gets the passwords and names of all wifi networks 
used by a computer.

This software is for educational purposes only!!
1. run program(can be used on external storage devices).
2. Follow the prompts.
3. if you choose to save the passwords a file named "passwords.txt" 
   will be created and or added on to.

Created By: Drew Quashie